# Shining Saturn 360

Emulador de Sega Saturn para Xbox 360 RGH.

**Versão de desenvolvimento:** `v0.39b`

## Estado verificado

- O workflow do GitHub Actions conseguiu iniciar o contêiner `free60/libxenon:latest` e fazer checkout do repositório.
- A etapa de verificação da toolchain falhou com código `127`: `xenon-gcc`, `xenon-ld` e/ou `elf2xex` não foram encontrados no `PATH` usado nessa execução.
- Ainda não existe uma compilação confirmada desta versão produzindo `Xenon.elf` e `default.xex`.
- A presença e a integração do código-fonte necessário para uma compilação completa ainda precisam ser verificadas.
- Não há testes de compatibilidade de jogos Saturn confirmados nesta versão.

## Próximos passos

1. Verificar a localização real dos executáveis Xenon dentro do contêiner.
2. Ajustar o `PATH` do workflow com base nessa verificação.
3. Inspecionar e integrar o código-fonte do emulador e um `Makefile` funcional.
4. Compilar e validar `Xenon.elf`.
5. Converter para `default.xex` usando a ferramenta apropriada e validar o arquivo resultante.
6. Executar testes no Xbox 360 RGH e registrar os resultados por jogo.

## Importante

Este repositório não deve declarar `Xenon.elf` ou `default.xex` como disponíveis até que os artefatos tenham sido gerados e verificados. A versão `v0.39b` identifica o estado de desenvolvimento/documentação, não uma compilação funcional comprovada.
