# Build status — v0.25b

- Local host regression tests: passed in this working environment (`HOST TESTS: PASS`).
- New SH-2 implementation: `SUB Rm,Rn` register subtraction.
- New regression cases: signed-boundary wraparound, unsigned wraparound, equal operands, and preservation of the `T` flag.
- Shell script syntax checks: passed.
- ZIP integrity check: passed.
- CI workflow: prepared but has not been run in the user's GitHub repository.
- libXenon target build: not run/verified in this environment.
- `Xenon.elf32`: not confirmed generated.
- `default.xex`: not produced/confirmed.
- Xbox 360 RGH execution: not performed.
- Scope: incremental emulator bootstrap, not a complete Sega Saturn emulator.


## v0.26b update
- Added CMP/EQ register and sign-extended immediate regression coverage.
- Host test status must be taken from the test run for this package.
- Xenon cross-build and console execution remain unverified.
