# Shining Saturn 360 v0.26b

## CPU regression coverage
- Added host regression tests for `CMP/EQ Rm,Rn`.
- Added immediate `CMP/EQ #imm8,R0` tests for sign-extended `-1` and positive `+1`.
- Verified that equality sets the SH-2 T flag and inequality clears it.
- Existing CPU, memory-bus, scheduler, and core smoke tests remain in the suite.

## Validation boundary
Host tests validate this subset in the available host environment. A libXenon cross-build, confirmed `Xenon.elf32`, `default.xex`, and Xbox 360 RGH execution have not been verified in this release.
