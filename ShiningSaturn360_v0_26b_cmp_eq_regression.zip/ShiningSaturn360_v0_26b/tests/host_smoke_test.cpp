#include "shining/core/saturn_core.h"
#include "shining/cpu/sh2.h"
#include "shining/memory/memory_bus.h"
#include "shining/scheduler/scheduler.h"
#include <cassert>
#include <cstdint>

int main() {
    using namespace shining;

    MemoryBus bus(4096);
    assert(bus.size() == 4096);
    assert(bus.read8(3) == 0);
    bus.write8(3, 0xA5);
    assert(bus.read8(3) == 0xA5);
    bus.write8(4096, 0xFF); // out-of-range writes must be ignored
    assert(bus.read8(4096) == 0);
    bus.write16(4, 0x1234);
    assert(bus.read8(4) == 0x12 && bus.read8(5) == 0x34);
    assert(bus.read16(4) == 0x1234);
    bus.write32(8, 0x89ABCDEFu);
    assert(bus.read8(8) == 0x89 && bus.read8(9) == 0xAB);
    assert(bus.read16(10) == 0xCDEF);
    assert(bus.read32(8) == 0x89ABCDEFu);
    bus.write32(4094, 0xFFFFFFFFu); // partial writes must be ignored
    assert(bus.read32(4094) == 0);
    bus.reset();
    assert(bus.read8(3) == 0);

    SH2 cpu(bus);
    // SH-2 instruction words are fetched in big-endian order.
    bus.reset();
    bus.write16(0x100, 0xE1FE); // MOV #-2,R1
    bus.write16(0x102, 0x7103); // ADD #3,R1
    bus.write16(0x104, 0xE200); // MOV #0,R2
    bus.write16(0x106, 0x321C); // ADD R1,R2
    bus.write16(0x108, 0x6323); // MOV R2,R3
    bus.write16(0x10A, 0x0009); // NOP
    bus.write16(0x10C, 0xFFFF); // unsupported opcode is counted
    cpu.reset(0x100);
    cpu.step();
    assert(cpu.pc() == 0x102 && cpu.reg(1) == 0xFFFFFFFEu);
    cpu.step();
    assert(cpu.reg(1) == 1u);
    cpu.step();
    assert(cpu.reg(2) == 0u);
    cpu.step();
    assert(cpu.reg(2) == 1u);
    cpu.step();
    assert(cpu.reg(3) == 1u);
    cpu.step();
    assert(cpu.last_opcode() == 0x0009u);
    cpu.step();
    assert(cpu.unsupported_opcodes() == 1u);
    assert(cpu.pc() == 0x10E && cpu.cycles() == 7);
    cpu.reset(0x100);
    assert(cpu.reg(1) == 0 && cpu.cycles() == 0 && cpu.unsupported_opcodes() == 0);

    // T-bit, compare, decrement-and-test, and conditional branches.
    bus.reset();
    bus.write16(0x200, 0xE001); // MOV #1,R0
    bus.write16(0x202, 0x8801); // CMP/EQ #1,R0 -> T=1
    bus.write16(0x204, 0x8901); // BT to 0x20A
    bus.write16(0x206, 0xE055); // skipped
    bus.write16(0x20A, 0xE106); // MOV #6,R1
    bus.write16(0x20C, 0x4110); // DT R1 -> 5, T=0
    bus.write16(0x20E, 0x0029); // MOVT R0 -> 0
    cpu.reset(0x200);
    cpu.step();
    cpu.step();
    assert(cpu.t_bit());
    cpu.step();
    assert(cpu.pc() == 0x20A);
    cpu.step();
    assert(cpu.reg(1) == 6);
    cpu.step();
    assert(cpu.reg(1) == 5 && !cpu.t_bit());
    cpu.step();
    assert(cpu.reg(0) == 0);

    // BRA executes exactly one delay-slot instruction before taking the branch.
    bus.reset();
    bus.write16(0x300, 0xA001); // BRA 0x306
    bus.write16(0x302, 0xE107); // delay slot: MOV #7,R1
    bus.write16(0x304, 0xE108); // skipped
    bus.write16(0x306, 0xE209); // MOV #9,R2
    cpu.reset(0x300);
    cpu.step();
    assert(cpu.pc() == 0x302 && cpu.reg(1) == 0);
    cpu.step();
    assert(cpu.pc() == 0x306 && cpu.reg(1) == 7);
    cpu.step();
    assert(cpu.reg(2) == 9);

    // BSR records the return address and also honors its delay slot.
    bus.reset();
    bus.write16(0x400, 0xB001); // BSR 0x406
    bus.write16(0x402, 0xE103); // delay slot
    bus.write16(0x406, 0x000B); // RTS
    bus.write16(0x408, 0xE204); // return address
    cpu.reset(0x400);
    cpu.step();
    assert(cpu.pr() == 0x404);
    cpu.step();
    assert(cpu.pc() == 0x406 && cpu.reg(1) == 3);
    cpu.step();
    assert(cpu.pc() == 0x408);
    cpu.step();
    assert(cpu.reg(2) == 4);


    // SH-2 memory transfer instructions: byte/word sign extension,
    // longword transfers, post-increment and pre-decrement addressing.
    bus.reset();
    bus.write32(0x40, 0x80FFFEDCu);
    bus.write32(0x44, 0x12345678u);
    bus.write16(0x48, 0xFEDCu);
    bus.write8(0x4A, 0x80u);
    bus.write16(0x4B, 0xA1B2u);

    // Set R1=0x40, then load byte, word and longword from memory.
    bus.write16(0x500, 0xE140); // MOV #0x40,R1
    bus.write16(0x502, 0x6110); // MOV.B @R1,R1 (same-register case: no postincrement)
    bus.write16(0x504, 0xE140); // MOV #0x40,R1
    bus.write16(0x506, 0x6214); // MOV.B @R1+,R2
    bus.write16(0x508, 0x6315); // MOV.W @R1+,R3
    bus.write16(0x50A, 0x6416); // MOV.L @R1+,R4
    bus.write16(0x50C, 0xE550); // MOV #0x50,R5
    bus.write16(0x50E, 0x2552); // MOV.L R5,@R5? replaced below
    bus.write16(0x510, 0xE650); // MOV #0x50,R6
    bus.write16(0x512, 0x2656); // MOV.L R5,@-R6

    cpu.reset(0x500);
    cpu.step();
    cpu.step();
    assert(cpu.reg(1) == 0xFFFFFF80u); // sign-extended byte; Rn==Rm means no increment
    cpu.step();
    cpu.step();
    assert(cpu.reg(2) == 0xFFFFFF80u && cpu.reg(1) == 0x41u);
    cpu.step();
    assert(cpu.reg(3) == 0xFFFFFFFEu && cpu.reg(1) == 0x43u);
    cpu.step();
    assert(cpu.reg(4) == 0xDC123456u && cpu.reg(1) == 0x47u);
    cpu.step();
    assert(cpu.reg(5) == 0x50u);
    // Correct the source/destination register roles for pre-decrement store.
    // The instruction at 0x50E is an ordinary long store from R5 to [R5].
    cpu.step();
    assert(bus.read32(0x50) == 0x00000050u);
    cpu.step();
    assert(cpu.reg(6) == 0x50u);
    cpu.step();
    assert(cpu.reg(6) == 0x4Cu && bus.read32(0x4C) == 0x00000050u);


    // v0.14b logical and data-format operations.
    bus.reset();
    bus.write16(0x600, 0xE1F0); // MOV #-16,R1 => 0xFFFFFFF0
    bus.write16(0x602, 0xE20F); // MOV #15,R2
    bus.write16(0x604, 0x2219); // AND R1,R2 => 0
    bus.write16(0x606, 0xE312); // MOV #18,R3
    bus.write16(0x608, 0xE404); // MOV #4,R4
    bus.write16(0x60A, 0x234B); // OR R4,R3 => 22
    bus.write16(0x60C, 0xE504); // MOV #4,R5
    bus.write16(0x60E, 0x235A); // XOR R5,R3 => 18
    bus.write16(0x610, 0xE6A5); // MOV #-91,R6 (0xFFFFFFA5)
    bus.write16(0x612, 0x666C); // EXTU.B R6,R6 => 0xA5
    bus.write16(0x614, 0x666E); // EXTS.B R6,R6 => 0xFFFFFFA5
    bus.write16(0x616, 0xE700); // MOV #0,R7
    bus.write16(0x618, 0x677B); // NEG R7,R7 => 0
    bus.write16(0x61A, 0xE812); // MOV #18,R8
    bus.write16(0x61C, 0x6887); // NOT R8,R8 => ~18
    bus.write16(0x61E, 0xE912); // MOV #18,R9
    bus.write16(0x620, 0x6998); // SWAP.B R9,R9
    bus.write16(0x622, 0xEA00); // MOV #0,R10
    bus.write16(0x624, 0x2A18); // TST R1,R10 => T=1
    bus.write16(0x626, 0x2A28); // TST R2,R10 => T=1 (R2=0)
    cpu.reset(0x600);
    cpu.step(); cpu.step(); cpu.step();
    assert(cpu.reg(2) == 0u);
    cpu.step(); cpu.step(); cpu.step();
    assert(cpu.reg(3) == 22u);
    cpu.step(); cpu.step();
    assert(cpu.reg(3) == 18u);
    cpu.step(); cpu.step();
    assert(cpu.reg(6) == 0xA5u);
    cpu.step();
    assert(cpu.reg(6) == 0xFFFFFFA5u);
    cpu.step(); cpu.step();
    assert(cpu.reg(7) == 0u);
    cpu.step(); cpu.step();
    assert(cpu.reg(8) == ~18u);
    cpu.step(); cpu.step();
    assert(cpu.reg(9) == 0x1200u);
    cpu.step(); cpu.step();
    assert(cpu.t_bit());


    // v0.15b SH-2 shift/rotate operations and T-bit behavior.
    bus.reset();
    bus.write16(0x700, 0xE180); // MOV #-128,R1 => 0xFFFFFF80
    bus.write16(0x702, 0x4100); // SHLL R1 => 0xFFFFFF00, T=1
    bus.write16(0x704, 0x4101); // SHLR R1 => 0x7FFFFF80, T=0
    bus.write16(0x706, 0xE280); // MOV #-128,R2
    bus.write16(0x708, 0x4204); // ROTL R2 => 0xFFFFFF01, T=1
    bus.write16(0x70A, 0xE300); // MOV #0,R3
    bus.write16(0x70C, 0x4305); // ROTR R3 => 0, T=0
    bus.write16(0x70E, 0xE480); // MOV #-128,R4
    bus.write16(0x710, 0x4420); // SHAL R4 => 0xFFFFFF00, T=1
    bus.write16(0x712, 0xE580); // MOV #-128,R5
    bus.write16(0x714, 0x4521); // SHAR R5 => 0xFFFFFFC0, T=0
    bus.write16(0x716, 0xE680); // MOV #-128,R6
    bus.write16(0x718, 0x4624); // ROTCL R6 with T=0 => shift left, T=1
    bus.write16(0x71A, 0xE780); // MOV #-128,R7
    bus.write16(0x71C, 0x4725); // ROTCR R7 with T=0 => 0x7FFFFFC0, T=0
    bus.write16(0x71E, 0xE812); // MOV #18,R8
    bus.write16(0x720, 0x4808); // SHLL2 R8 => 72
    bus.write16(0x722, 0xE912); // MOV #18,R9
    bus.write16(0x724, 0x4909); // SHLR2 R9 => 4
    bus.write16(0x726, 0xEA12); // MOV #18,R10
    bus.write16(0x728, 0x4A18); // SHLL8 R10 => 0x1200
    bus.write16(0x72A, 0xEB12); // MOV #18,R11
    bus.write16(0x72C, 0x4B19); // SHLR8 R11 => 0
    bus.write16(0x72E, 0xEC12); // MOV #18,R12
    bus.write16(0x730, 0x4C28); // SHLL16 R12 => 0x00120000
    bus.write16(0x732, 0xED12); // MOV #18,R13
    bus.write16(0x734, 0x4D29); // SHLR16 R13 => 0
    cpu.reset(0x700);
    cpu.step(); cpu.step();
    assert(cpu.reg(1) == 0xFFFFFF00u && cpu.t_bit());
    cpu.step();
    assert(cpu.reg(1) == 0x7FFFFF80u && !cpu.t_bit());
    cpu.step(); cpu.step();
    assert(cpu.reg(2) == 0xFFFFFF01u && cpu.t_bit());
    cpu.step(); cpu.step();
    assert(cpu.reg(3) == 0u && !cpu.t_bit());
    cpu.step(); cpu.step();
    assert(cpu.reg(4) == 0xFFFFFF00u && cpu.t_bit());
    cpu.step(); cpu.step();
    assert(cpu.reg(5) == 0xFFFFFFC0u && !cpu.t_bit());
    cpu.step(); cpu.step();
    assert(cpu.reg(6) == 0xFFFFFF00u && cpu.t_bit());
    cpu.step(); cpu.step();
    assert(cpu.reg(7) == 0xFFFFFFC0u && !cpu.t_bit());
    cpu.step(); cpu.step();
    assert(cpu.reg(8) == 72u);
    cpu.step(); cpu.step();
    assert(cpu.reg(9) == 4u);
    cpu.step(); cpu.step();
    assert(cpu.reg(10) == 0x1200u);
    cpu.step(); cpu.step();
    assert(cpu.reg(11) == 0u);
    cpu.step(); cpu.step();
    assert(cpu.reg(12) == 0x00120000u);
    cpu.step(); cpu.step();
    assert(cpu.reg(13) == 0u);

    // v0.16b immediate logical operations on R0.
    bus.reset();
    bus.write16(0x800, 0xE05A); // MOV #0x5A,R0
    bus.write16(0x802, 0xC8A5); // TST #0xA5,R0 -> T=1 (no common bits)
    bus.write16(0x804, 0xC900); // AND #0,R0 -> 0
    bus.write16(0x806, 0xC8FF); // TST #0xFF,R0 -> T=1
    bus.write16(0x808, 0xE012); // MOV #0x12,R0
    bus.write16(0x80A, 0xCA0F); // XOR #0x0F,R0 -> 0x1D
    bus.write16(0x80C, 0xCB80); // OR #0x80,R0 -> 0x9D
    cpu.reset(0x800);
    cpu.step();
    assert(cpu.reg(0) == 0x5Au);
    cpu.step();
    assert(cpu.t_bit());
    cpu.step();
    assert(cpu.reg(0) == 0u);
    cpu.step();
    assert(cpu.t_bit());
    cpu.step();
    assert(cpu.reg(0) == 0x12u);
    cpu.step();
    assert(cpu.reg(0) == 0x1Du);
    cpu.step();
    assert(cpu.reg(0) == 0x9Du);

    // SHAR uses an explicit arithmetic shift helper, avoiding reliance on
    // implementation-defined right shift of negative signed integers.
    bus.reset();
    bus.write16(0x820, 0xE180); // MOV #-128,R1 => 0xFFFFFF80
    bus.write16(0x822, 0x4121); // SHAR R1 => 0xFFFFFFC0, T=0
    cpu.reset(0x820);
    cpu.step();
    cpu.step();
    assert(cpu.reg(1) == 0xFFFFFFC0u && !cpu.t_bit());

    // v0.17b signed/unsigned comparisons and CMP/PZ/CMP/PL.
    bus.reset();
    bus.write16(0x840, 0xE1FF); // MOV #-1,R1 -> 0xFFFFFFFF
    bus.write16(0x842, 0xE201); // MOV #1,R2
    bus.write16(0x844, 0x3212); // CMP/HS R1,R2: unsigned 1 >= 0xFFFFFFFF -> false
    bus.write16(0x846, 0x3213); // CMP/GE R1,R2: signed 1 >= -1 -> true
    bus.write16(0x848, 0x3216); // CMP/HI R1,R2: unsigned 1 > 0xFFFFFFFF -> false
    bus.write16(0x84A, 0x3217); // CMP/GT R1,R2: signed 1 > -1 -> true
    bus.write16(0x84C, 0xE300); // MOV #0,R3
    bus.write16(0x84E, 0x4311); // CMP/PZ R3: zero >= 0 -> true
    bus.write16(0x850, 0x4315); // CMP/PL R3: zero > 0 -> false
    bus.write16(0x852, 0x4311); // CMP/PZ R3 after prior T=0 -> true
    cpu.reset(0x840);
    cpu.step(); assert(cpu.reg(1) == 0xFFFFFFFFu);
    cpu.step(); assert(cpu.reg(2) == 1u);
    cpu.step(); assert(!cpu.t_bit());
    cpu.step(); assert(cpu.t_bit());
    cpu.step(); assert(!cpu.t_bit());
    cpu.step(); assert(cpu.t_bit());
    cpu.step(); assert(cpu.reg(3) == 0u);
    cpu.step(); assert(cpu.t_bit());
    cpu.step(); assert(!cpu.t_bit());
    cpu.step(); assert(cpu.t_bit());

    // Equal operands distinguish >= from > for both signed and unsigned.
    bus.reset();
    bus.write16(0x860, 0xE411); // MOV #17,R4
    bus.write16(0x862, 0xE511); // MOV #17,R5
    bus.write16(0x864, 0x3542); // CMP/HS R4,R5 -> true
    bus.write16(0x866, 0x3543); // CMP/GE R4,R5 -> true
    bus.write16(0x868, 0x3546); // CMP/HI R4,R5 -> false
    bus.write16(0x86A, 0x3547); // CMP/GT R4,R5 -> false
    cpu.reset(0x860);
    cpu.step(); cpu.step(); cpu.step(); assert(cpu.t_bit());
    cpu.step(); assert(cpu.t_bit());
    cpu.step(); assert(!cpu.t_bit());
    cpu.step(); assert(!cpu.t_bit());

    // CMP/PL is false for zero and negative, true for positive.
    bus.reset();
    bus.write16(0x880, 0xE600); // MOV #0,R6
    bus.write16(0x882, 0x4615); // CMP/PL R6 -> false
    bus.write16(0x884, 0xE680); // MOV #-128,R6
    bus.write16(0x886, 0x4615); // CMP/PL R6 -> false
    bus.write16(0x888, 0xE601); // MOV #1,R6
    bus.write16(0x88A, 0x4615); // CMP/PL R6 -> true
    cpu.reset(0x880);
    cpu.step(); cpu.step(); assert(!cpu.t_bit());
    cpu.step(); cpu.step(); assert(!cpu.t_bit());
    cpu.step(); cpu.step(); assert(cpu.t_bit());

    // v0.18b: CPU context checkpoint restores architectural and delay-slot state.
    bus.reset();
    bus.write16(0x900, 0xA002); // BRA target 0x908, pending after this step
    bus.write16(0x902, 0xE107); // delay slot: MOV #7,R1
    bus.write16(0x908, 0xE209); // MOV #9,R2
    cpu.reset(0x900);
    cpu.step();
    const SH2State checkpoint = cpu.save_state();
    assert(checkpoint.pc == 0x902 && checkpoint.branch_pending);
    assert(checkpoint.branch_target == 0x908 && checkpoint.cycles == 1);
    cpu.step();
    assert(cpu.pc() == 0x908 && cpu.reg(1) == 7);
    cpu.step();
    assert(cpu.reg(2) == 9);
    cpu.load_state(checkpoint);
    assert(cpu.pc() == 0x902 && cpu.reg(1) == 0);
    assert(cpu.cycles() == 1 && cpu.last_opcode() == 0xA002);
    cpu.step();
    assert(cpu.pc() == 0x908 && cpu.reg(1) == 7);
    cpu.step();
    assert(cpu.reg(2) == 9 && cpu.cycles() == 3);

    // v0.22b: carry/borrow, signed overflow, byte comparison and extraction.
    bus.reset();
    bus.write16(0xA00, 0xE1FF); // MOV #-1,R1
    bus.write16(0xA02, 0xE200); // MOV #0,R2
    bus.write16(0xA04, 0x312E); // ADDC R2,R1: -1 + 0 + T(0), no carry
    bus.write16(0xA06, 0xE3FF); // MOV #-1,R3
    bus.write16(0xA08, 0x313E); // ADDC R3,R1: 0xFFFFFFFE + 0xFFFFFFFF -> carry
    bus.write16(0xA0A, 0xE4FF); // MOV #-1,R4
    bus.write16(0xA0C, 0x4401); // SHLR R4 -> 0x7FFFFFFF
    bus.write16(0xA0E, 0xE501); // MOV #1,R5
    bus.write16(0xA10, 0x354F); // ADDV R4,R5
    bus.write16(0xA12, 0xE600); // MOV #0,R6
    bus.write16(0xA14, 0xE700); // MOV #0,R7
    bus.write16(0xA16, 0x276C); // CMP/STR R6,R7 -> T=1 (matching bytes)
    bus.write16(0xA18, 0xE812); // MOV #0x12,R8
    bus.write16(0xA1A, 0xE934); // MOV #0x34,R9
    bus.write16(0xA1C, 0x289D); // XTRCT R9,R8
    cpu.reset(0xA00);
    cpu.step(); cpu.step(); cpu.step();
    assert(cpu.reg(1) == 0xFFFFFFFFu && !cpu.t_bit());
    cpu.step(); cpu.step();
    assert(cpu.reg(1) == 0xFFFFFFFEu && cpu.t_bit());
    cpu.step(); cpu.step(); cpu.step(); cpu.step();
    assert(cpu.reg(5) == 0x80000000u && cpu.t_bit());
    cpu.step(); cpu.step(); cpu.step();
    assert(cpu.t_bit());
    cpu.step(); cpu.step(); cpu.step();
    assert(cpu.reg(8) == 0x00340000u);

    // v0.23b: TAS.B sets the high bit atomically and reports zero in T.
    bus.reset();
    bus.write16(0xC00, 0x411B); // TAS.B @R1
    SH2State tas_state = cpu.save_state();
    tas_state.pc = 0xC00;
    tas_state.regs[1] = 0x300;
    tas_state.sr = 0;
    bus.write8(0x300, 0x00);
    cpu.load_state(tas_state);
    cpu.step();
    assert(bus.read8(0x300) == 0x80 && cpu.t_bit());
    tas_state = cpu.save_state();
    tas_state.pc = 0xC00;
    tas_state.sr = 0;
    bus.write8(0x300, 0x25);
    cpu.load_state(tas_state);
    cpu.step();
    assert(bus.read8(0x300) == 0xA5 && !cpu.t_bit());

    // SUBC propagates borrow-in and reports an unsigned borrow in T.
    bus.reset();
    bus.write16(0xB00, 0xE100); // MOV #0,R1
    bus.write16(0xB02, 0xE201); // MOV #1,R2
    bus.write16(0xB04, 0x312A); // SUBC R2,R1 -> 0xFFFFFFFF, T=1
    cpu.reset(0xB00);
    cpu.step(); cpu.step(); cpu.step();
    assert(cpu.reg(1) == 0xFFFFFFFFu && cpu.t_bit());

    // v0.24b: signed/unsigned comparison and sign-boundary regression tests.
    // Register encodings exercise CMP/HS, CMP/GE, CMP/HI, CMP/GT, CMP/PZ and CMP/PL.
    bus.reset();
    bus.write16(0xD00, 0xE1FF); // R1 = -1 (0xFFFFFFFF)
    bus.write16(0xD02, 0xE200); // R2 = 0
    bus.write16(0xD04, 0x3122); // CMP/HS R2,R1: unsigned 0xFFFFFFFF >= 0 => T=1
    bus.write16(0xD06, 0x3133); // CMP/GE R3,R1: R3 is 0; signed -1 >= 0 => T=0
    bus.write16(0xD08, 0x3126); // CMP/HI R2,R1: unsigned 0xFFFFFFFF > 0 => T=1
    bus.write16(0xD0A, 0x3137); // CMP/GT R3,R1: signed -1 > 0 => T=0
    bus.write16(0xD0C, 0x4111); // CMP/PZ R1: -1 >= 0 => T=0
    bus.write16(0xD0E, 0x4215); // CMP/PL R2: 0 > 0 => T=0
    bus.write16(0xD10, 0xE380); // R3 = -128
    bus.write16(0xD12, 0x4311); // CMP/PZ R3: negative => T=0
    bus.write16(0xD14, 0xE401); // R4 = 1
    bus.write16(0xD16, 0x4415); // CMP/PL R4: positive => T=1
    cpu.reset(0xD00);
    cpu.step(); cpu.step(); cpu.step();
    assert(cpu.t_bit());
    cpu.step(); assert(!cpu.t_bit());
    cpu.step(); assert(cpu.t_bit());
    cpu.step(); assert(!cpu.t_bit());
    cpu.step(); assert(!cpu.t_bit());
    cpu.step(); assert(!cpu.t_bit());
    cpu.step(); cpu.step(); assert(!cpu.t_bit());
    cpu.step(); cpu.step(); assert(cpu.t_bit());

    // v0.25b: SUB Rm,Rn arithmetic wraparound and signed-boundary tests.
    bus.reset();
    bus.write16(0xE00, 0x3128); // SUB R2,R1
    SH2State sub_state = cpu.save_state();
    sub_state.pc = 0xE00;
    sub_state.regs[1] = 0x80000000u; // INT32_MIN
    sub_state.regs[2] = 1u;
    sub_state.sr = 1u; // SUB must not alter T
    cpu.load_state(sub_state);
    cpu.step();
    assert(cpu.reg(1) == 0x7FFFFFFFu);
    assert(cpu.t_bit());

    sub_state = cpu.save_state();
    sub_state.pc = 0xE00;
    sub_state.regs[1] = 0u;
    sub_state.regs[2] = 1u;
    sub_state.sr = 0u;
    cpu.load_state(sub_state);
    cpu.step();
    assert(cpu.reg(1) == 0xFFFFFFFFu);
    assert(!cpu.t_bit()); // SUB does not modify the T flag

    sub_state = cpu.save_state();
    sub_state.pc = 0xE00;
    sub_state.regs[1] = 0xFFFFFFFFu;
    sub_state.regs[2] = 0xFFFFFFFFu;
    sub_state.sr = 1u;
    cpu.load_state(sub_state);
    cpu.step();
    assert(cpu.reg(1) == 0u);
    assert(cpu.t_bit());

    // v0.26b: CMP/EQ register and sign-extended immediate regression tests.
    bus.reset();
    bus.write16(0xE20, 0x3120); // CMP/EQ R2,R1
    bus.write16(0xE22, 0x88FF); // CMP/EQ #-1,R0
    bus.write16(0xE24, 0x8801); // CMP/EQ #1,R0
    SH2State cmp_state = cpu.save_state();
    cmp_state.pc = 0xE20;
    cmp_state.regs[1] = 0x12345678u;
    cmp_state.regs[2] = 0x12345678u;
    cmp_state.regs[0] = 0xFFFFFFFFu;
    cmp_state.sr = 0u;
    cpu.load_state(cmp_state);
    cpu.step();
    assert(cpu.t_bit()); // equal registers
    cpu.step();
    assert(cpu.t_bit()); // R0 equals sign-extended -1
    cpu.step();
    assert(!cpu.t_bit()); // R0 does not equal +1

    cmp_state = cpu.save_state();
    cmp_state.pc = 0xE20;
    cmp_state.regs[1] = 0x12345678u;
    cmp_state.regs[2] = 0x87654321u;
    cmp_state.sr = 1u;
    cpu.load_state(cmp_state);
    cpu.step();
    assert(!cpu.t_bit()); // unequal registers clear T

    Scheduler scheduler;
    scheduler.tick(7);
    assert(scheduler.cycles() == 7);
    scheduler.reset();
    assert(scheduler.cycles() == 0);

    SaturnCore core;
    assert(!core.initialized());
    assert(core.initialize());
    assert(core.initialized());
    core.run_frame();
    assert(core.frame_count() == 1);
    assert(core.scheduler_cycles() == 2000);
    core.reset();
    assert(core.frame_count() == 0);
    assert(core.scheduler_cycles() == 0);
    core.shutdown();
    assert(!core.initialized());
    return 0;
}
