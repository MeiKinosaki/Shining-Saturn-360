#!/usr/bin/env bash
set -u
ELF="${1:-}"
[[ -f "$ELF" ]] || { echo "Usage: $0 path/to/xenon.elf"; exit 2; }
command -v readelf >/dev/null 2>&1 || { echo "ERROR: readelf ausente"; exit 2; }
readelf -h "$ELF" || exit 1
python3 - "$ELF" <<'PY'
import struct,sys
b=open(sys.argv[1],"rb").read(64)
if b[:4] != b'\x7fELF': raise SystemExit("invalid ELF")
if b[4] != 1: raise SystemExit("not ELF32")
if b[5] != 2: raise SystemExit("not big-endian")
machine=struct.unpack(">H",b[18:20])[0]
entry=struct.unpack(">I",b[24:28])[0]
if machine != 20: raise SystemExit(f"wrong machine {machine}, expected PowerPC(20)")
if entry == 0: raise SystemExit("entry point is zero")
print(f"ELF VALIDATION: OK, PowerPC, entry=0x{entry:08x}")
PY
