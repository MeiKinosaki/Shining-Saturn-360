#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
CXX="${CXX:-g++}"
OUT="${TMPDIR:-/tmp}/shining-saturn-host-smoke-test"
"$CXX" -std=c++11 -Wall -Wextra -Werror -I"$ROOT/include" \
  "$ROOT/tests/host_smoke_test.cpp" \
  "$ROOT/src/core/saturn_core.cpp" \
  "$ROOT/src/cpu/sh2.cpp" \
  "$ROOT/src/memory/memory_bus.cpp" \
  "$ROOT/src/scheduler/scheduler.cpp" \
  -o "$OUT"
"$OUT"
echo "HOST TESTS: PASS"
