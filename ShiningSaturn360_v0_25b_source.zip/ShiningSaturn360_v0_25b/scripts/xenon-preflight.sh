#!/usr/bin/env bash
set -u
DEVKITXENON="${DEVKITXENON:-/usr/local/xenon}"
PATH="${PATH:+${PATH}:}${DEVKITXENON}/bin:${DEVKITXENON}/usr/bin"
export PATH

echo "=== Shining Saturn 360 — libXenon preflight v0.13b ==="
echo "DEVKITXENON=$DEVKITXENON"
missing=0

check_tool() {
  local tool="$1"
  if command -v "$tool" >/dev/null 2>&1; then
    printf '[OK] tool: %s (%s)\n' "$tool" "$(command -v "$tool")"
  else
    printf '[MISS] tool: %s\n' "$tool"
    missing=1
  fi
}

check_file() {
  local file="$1"
  if [[ -f "$file" ]]; then
    printf '[OK] file: %s\n' "$file"
  else
    printf '[MISS] file: %s\n' "$file"
    missing=1
  fi
}

for tool in xenon-gcc xenon-g++ xenon-objcopy xenon-strip; do
  check_tool "$tool"
done
check_file "${DEVKITXENON}/rules"
check_file "${DEVKITXENON}/app.lds"
check_file "${DEVKITXENON}/usr/lib/libxenon.a"
check_file "${DEVKITXENON}/usr/include/input/input.h"
check_file "${DEVKITXENON}/usr/include/xenos/xenos.h"

if [[ -f "${DEVKITXENON}/rules" ]]; then
  if grep -Eq '^%\.elf32:[[:space:]]*%\.elf' "${DEVKITXENON}/rules" && \
     grep -Eq '^%\.elf:' "${DEVKITXENON}/rules"; then
    echo '[OK] rules include ELF and ELF32 recipes'
  else
    echo '[WARN] rules file exists, but expected ELF/ELF32 pattern was not detected; inspect make output'
  fi
fi

if [[ $missing -eq 0 ]]; then
  echo 'XENON PREFLIGHT: READY'
  exit 0
fi
echo 'XENON PREFLIGHT: BLOCKED'
exit 2
