#!/usr/bin/env bash
set -euo pipefail
cat <<'MSG'
Este pacote usa o fluxo oficial libXenon/XeLL: primeiro produza um ELF32 e teste-o via XeLL.
A documentação oficial de xenon-examples não define conversão genérica para default.xex.
Não será criado um default.xex fictício. Um alvo XEX exige uma toolchain/SDK e um processo
separados, compatíveis com o formato XEX desejado.
MSG
exit 2
