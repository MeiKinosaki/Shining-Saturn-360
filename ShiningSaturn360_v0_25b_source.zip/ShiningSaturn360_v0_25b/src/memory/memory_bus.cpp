#include "shining/memory/memory_bus.h"
#include <algorithm>

namespace shining {
MemoryBus::MemoryBus(size_t size): ram_(size, 0) {}
void MemoryBus::reset() { std::fill(ram_.begin(), ram_.end(), 0); }

uint8_t MemoryBus::read8(uint32_t address) const {
    return address < ram_.size() ? ram_[address] : 0;
}

uint16_t MemoryBus::read16(uint32_t address) const {
    if (address >= ram_.size() || ram_.size() - address < 2) return 0;
    return static_cast<uint16_t>((static_cast<uint16_t>(ram_[address]) << 8) |
                                 static_cast<uint16_t>(ram_[address + 1]));
}

uint32_t MemoryBus::read32(uint32_t address) const {
    if (address >= ram_.size() || ram_.size() - address < 4) return 0;
    return (static_cast<uint32_t>(ram_[address]) << 24) |
           (static_cast<uint32_t>(ram_[address + 1]) << 16) |
           (static_cast<uint32_t>(ram_[address + 2]) << 8) |
           static_cast<uint32_t>(ram_[address + 3]);
}

void MemoryBus::write8(uint32_t address, uint8_t value) {
    if (address < ram_.size()) ram_[address] = value;
}

void MemoryBus::write16(uint32_t address, uint16_t value) {
    if (address >= ram_.size() || ram_.size() - address < 2) return;
    ram_[address] = static_cast<uint8_t>(value >> 8);
    ram_[address + 1] = static_cast<uint8_t>(value);
}

void MemoryBus::write32(uint32_t address, uint32_t value) {
    if (address >= ram_.size() || ram_.size() - address < 4) return;
    ram_[address] = static_cast<uint8_t>(value >> 24);
    ram_[address + 1] = static_cast<uint8_t>(value >> 16);
    ram_[address + 2] = static_cast<uint8_t>(value >> 8);
    ram_[address + 3] = static_cast<uint8_t>(value);
}
}
