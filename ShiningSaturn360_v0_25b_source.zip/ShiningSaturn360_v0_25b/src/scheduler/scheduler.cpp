#include "shining/scheduler/scheduler.h"
namespace shining {
Scheduler::Scheduler(): cycles_(0) {}
void Scheduler::reset() { cycles_=0; }
void Scheduler::tick(uint32_t c) { cycles_ += c; }
}
