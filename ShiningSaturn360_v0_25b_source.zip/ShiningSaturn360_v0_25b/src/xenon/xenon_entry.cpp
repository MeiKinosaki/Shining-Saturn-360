#include "shining/core/saturn_core.h"

// libXenon homebrew examples use main() as the application entry point.
// This bootstrap is not yet the complete Saturn machine or video/input frontend.
int main()
{
    shining::SaturnCore core;
    if (!core.initialize())
        return 1;

    for (;;) {
        core.run_frame();
    }

    // The loop is intentionally continuous for the bare-metal prototype.
    // A future frontend should own exit/shutdown and controller polling.
    // return 0;
}
