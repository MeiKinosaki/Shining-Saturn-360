#include "shining/core/saturn_core.h"
namespace shining {
SaturnCore::SaturnCore(): memory_(), master_(memory_), slave_(memory_), initialized_(false), frame_count_(0) {}
bool SaturnCore::initialize() {
    reset();
    initialized_=true;
    return true;
}
void SaturnCore::reset() {
    memory_.reset();
    master_.reset(0);
    slave_.reset(0);
    scheduler_.reset();
    frame_count_=0;
}
void SaturnCore::run_frame() {
    if (!initialized_) return;
    // Account for each CPU step as it executes rather than adding a single
    // aggregate after the frame. This establishes a deterministic integration
    // point for future device events and timing synchronization.
    const uint32_t master_steps_per_frame = 1000;
    const uint32_t slave_steps_per_frame = 1000;
    for (uint32_t i = 0; i < master_steps_per_frame; ++i) {
        master_.step();
        scheduler_.tick(1);
    }
    for (uint32_t i = 0; i < slave_steps_per_frame; ++i) {
        slave_.step();
        scheduler_.tick(1);
    }
    ++frame_count_;
}
void SaturnCore::shutdown() { initialized_=false; }
}
