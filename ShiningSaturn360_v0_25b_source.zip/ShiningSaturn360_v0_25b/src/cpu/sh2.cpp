#include "shining/cpu/sh2.h"
#include "shining/memory/memory_bus.h"

namespace shining {
namespace {
inline int32_t sign_extend8(uint16_t value) {
    return static_cast<int32_t>(static_cast<int8_t>(value & 0x00FFu));
}
inline int32_t sign_extend12(uint16_t value) {
    int32_t result = static_cast<int32_t>(value & 0x0FFFu);
    if ((result & 0x0800) != 0) result -= 0x1000;
    return result;
}
inline uint32_t arithmetic_shift_right(uint32_t value, unsigned amount) {
    if (amount == 0) return value;
    const uint32_t shifted = value >> amount;
    if ((value & 0x80000000u) == 0) return shifted;
    return shifted | (~uint32_t(0) << (32u - amount));
}
}

SH2::SH2(MemoryBus& bus)
    : bus_(bus), pc_(0), pr_(0), sr_(0), branch_target_(0),
      branch_pending_(false), last_opcode_(0), cycles_(0),
      unsupported_opcodes_(0) {
    reset();
}

void SH2::reset(uint32_t pc) {
    pc_ = pc;
    for (unsigned i = 0; i < 16; ++i) regs_[i] = 0;
    pr_ = 0;
    sr_ = 0;
    branch_target_ = 0;
    branch_pending_ = false;
    last_opcode_ = 0;
    cycles_ = 0;
    unsupported_opcodes_ = 0;
}

void SH2::schedule_branch(uint32_t target) {
    branch_target_ = target;
    branch_pending_ = true;
}

SH2State SH2::save_state() const {
    SH2State state;
    for (unsigned i = 0; i < 16; ++i) state.regs[i] = regs_[i];
    state.pc = pc_;
    state.pr = pr_;
    state.sr = sr_;
    state.branch_target = branch_target_;
    state.branch_pending = branch_pending_;
    state.last_opcode = last_opcode_;
    state.cycles = cycles_;
    state.unsupported_opcodes = unsupported_opcodes_;
    return state;
}

void SH2::load_state(const SH2State& state) {
    for (unsigned i = 0; i < 16; ++i) regs_[i] = state.regs[i];
    pc_ = state.pc;
    pr_ = state.pr;
    sr_ = state.sr;
    branch_target_ = state.branch_target;
    branch_pending_ = state.branch_pending;
    last_opcode_ = state.last_opcode;
    cycles_ = state.cycles;
    unsupported_opcodes_ = state.unsupported_opcodes;
}

void SH2::step() {
    // Apply a branch scheduled by the preceding instruction only after this
    // instruction executes, preserving the single SH-2 delay slot.
    const bool apply_delayed_branch = branch_pending_;
    const uint32_t delayed_target = branch_target_;
    branch_pending_ = false;

    last_opcode_ = bus_.read16(pc_);
    pc_ += 2;

    const uint16_t op = last_opcode_;
    const unsigned n = (op >> 8) & 0x0Fu;
    const unsigned m = (op >> 4) & 0x0Fu;
    if (op == 0x0009u) {                         // NOP
    } else if (op == 0x0008u) {                  // CLRT
        sr_ &= ~1u;
    } else if (op == 0x0018u) {                  // SETT
        sr_ |= 1u;
    } else if (op == 0x0029u) {                  // MOVT Rn
        regs_[n] = t_bit() ? 1u : 0u;
    } else if ((op & 0xF000u) == 0xE000u) {      // MOV #imm8,Rn
        regs_[n] = static_cast<uint32_t>(sign_extend8(op));
    } else if ((op & 0xF000u) == 0x7000u) {      // ADD #imm8,Rn
        regs_[n] += static_cast<uint32_t>(sign_extend8(op));
    } else if ((op & 0xF00Fu) == 0x6003u) {      // MOV Rm,Rn
        regs_[n] = regs_[m];
    } else if ((op & 0xF00Fu) == 0x2000u) {      // MOV.B Rm,@Rn
        bus_.write8(regs_[n], static_cast<uint8_t>(regs_[m]));
    } else if ((op & 0xF00Fu) == 0x2001u) {      // MOV.W Rm,@Rn
        bus_.write16(regs_[n], static_cast<uint16_t>(regs_[m]));
    } else if ((op & 0xF00Fu) == 0x2002u) {      // MOV.L Rm,@Rn
        bus_.write32(regs_[n], regs_[m]);
    } else if ((op & 0xF00Fu) == 0x2004u) {      // MOV.B Rm,@-Rn
        regs_[n] -= 1u;
        bus_.write8(regs_[n], static_cast<uint8_t>(regs_[m]));
    } else if ((op & 0xF00Fu) == 0x2005u) {      // MOV.W Rm,@-Rn
        regs_[n] -= 2u;
        bus_.write16(regs_[n], static_cast<uint16_t>(regs_[m]));
    } else if ((op & 0xF00Fu) == 0x2006u) {      // MOV.L Rm,@-Rn
        regs_[n] -= 4u;
        bus_.write32(regs_[n], regs_[m]);
    } else if ((op & 0xF00Fu) == 0x6000u) {      // MOV.B @Rm,Rn (sign extend)
        regs_[n] = static_cast<uint32_t>(static_cast<int32_t>(
            static_cast<int8_t>(bus_.read8(regs_[m]))));
    } else if ((op & 0xF00Fu) == 0x6001u) {      // MOV.W @Rm,Rn (sign extend)
        regs_[n] = static_cast<uint32_t>(static_cast<int32_t>(
            static_cast<int16_t>(bus_.read16(regs_[m]))));
    } else if ((op & 0xF00Fu) == 0x6002u) {      // MOV.L @Rm,Rn
        regs_[n] = bus_.read32(regs_[m]);
    } else if ((op & 0xF00Fu) == 0x6004u) {      // MOV.B @Rm+,Rn
        regs_[n] = static_cast<uint32_t>(static_cast<int32_t>(
            static_cast<int8_t>(bus_.read8(regs_[m]))));
        if (m != n) regs_[m] += 1u;
    } else if ((op & 0xF00Fu) == 0x6005u) {      // MOV.W @Rm+,Rn
        regs_[n] = static_cast<uint32_t>(static_cast<int32_t>(
            static_cast<int16_t>(bus_.read16(regs_[m]))));
        if (m != n) regs_[m] += 2u;
    } else if ((op & 0xF00Fu) == 0x6006u) {      // MOV.L @Rm+,Rn
        regs_[n] = bus_.read32(regs_[m]);
        if (m != n) regs_[m] += 4u;
    } else if ((op & 0xF0FFu) == 0x4000u) {      // SHLL Rn
        const uint32_t old = regs_[n];
        if (old & 0x80000000u) sr_ |= 1u; else sr_ &= ~1u;
        regs_[n] = old << 1;
    } else if ((op & 0xF0FFu) == 0x4001u) {      // SHLR Rn
        const uint32_t old = regs_[n];
        if (old & 1u) sr_ |= 1u; else sr_ &= ~1u;
        regs_[n] = old >> 1;
    } else if ((op & 0xF0FFu) == 0x4004u) {      // ROTL Rn
        const uint32_t old = regs_[n];
        const uint32_t msb = old >> 31;
        if (msb) sr_ |= 1u; else sr_ &= ~1u;
        regs_[n] = (old << 1) | msb;
    } else if ((op & 0xF0FFu) == 0x4005u) {      // ROTR Rn
        const uint32_t old = regs_[n];
        const uint32_t lsb = old & 1u;
        if (lsb) sr_ |= 1u; else sr_ &= ~1u;
        regs_[n] = (old >> 1) | (lsb << 31);
    } else if ((op & 0xF0FFu) == 0x4020u) {      // SHAL Rn
        const uint32_t old = regs_[n];
        if (old & 0x80000000u) sr_ |= 1u; else sr_ &= ~1u;
        regs_[n] = old << 1;
    } else if ((op & 0xF0FFu) == 0x4021u) {      // SHAR Rn
        const uint32_t old = regs_[n];
        if (old & 1u) sr_ |= 1u; else sr_ &= ~1u;
        regs_[n] = arithmetic_shift_right(regs_[n], 1);
    } else if ((op & 0xF0FFu) == 0x4024u) {      // ROTCL Rn
        const uint32_t old = regs_[n];
        const uint32_t old_t = sr_ & 1u;
        const uint32_t msb = old >> 31;
        if (msb) sr_ |= 1u; else sr_ &= ~1u;
        regs_[n] = (old << 1) | old_t;
    } else if ((op & 0xF0FFu) == 0x4025u) {      // ROTCR Rn
        const uint32_t old = regs_[n];
        const uint32_t old_t = sr_ & 1u;
        const uint32_t lsb = old & 1u;
        if (lsb) sr_ |= 1u; else sr_ &= ~1u;
        regs_[n] = (old >> 1) | (old_t << 31);
    } else if ((op & 0xF0FFu) == 0x4008u) {      // SHLL2 Rn
        regs_[n] <<= 2;
    } else if ((op & 0xF0FFu) == 0x4009u) {      // SHLR2 Rn
        regs_[n] >>= 2;
    } else if ((op & 0xF0FFu) == 0x4018u) {      // SHLL8 Rn
        regs_[n] <<= 8;
    } else if ((op & 0xF0FFu) == 0x4019u) {      // SHLR8 Rn
        regs_[n] >>= 8;
    } else if ((op & 0xF0FFu) == 0x4028u) {      // SHLL16 Rn
        regs_[n] <<= 16;
    } else if ((op & 0xF0FFu) == 0x4029u) {      // SHLR16 Rn
        regs_[n] >>= 16;
    } else if ((op & 0xFF00u) == 0xC800u) {      // TST #imm8,R0
        if ((regs_[0] & static_cast<uint32_t>(op & 0x00FFu)) == 0) sr_ |= 1u;
        else sr_ &= ~1u;
    } else if ((op & 0xFF00u) == 0xC900u) {      // AND #imm8,R0
        regs_[0] &= static_cast<uint32_t>(op & 0x00FFu);
    } else if ((op & 0xFF00u) == 0xCA00u) {      // XOR #imm8,R0
        regs_[0] ^= static_cast<uint32_t>(op & 0x00FFu);
    } else if ((op & 0xFF00u) == 0xCB00u) {      // OR #imm8,R0
        regs_[0] |= static_cast<uint32_t>(op & 0x00FFu);
    } else if ((op & 0xF00Fu) == 0x2008u) {      // TST Rm,Rn
        if ((regs_[n] & regs_[m]) == 0) sr_ |= 1u;
        else sr_ &= ~1u;
    } else if ((op & 0xF00Fu) == 0x2009u) {      // AND Rm,Rn
        regs_[n] &= regs_[m];
    } else if ((op & 0xF00Fu) == 0x200Au) {      // XOR Rm,Rn
        regs_[n] ^= regs_[m];
    } else if ((op & 0xF00Fu) == 0x200Bu) {      // OR Rm,Rn
        regs_[n] |= regs_[m];
    } else if ((op & 0xF00Fu) == 0x6007u) {      // NOT Rm,Rn
        regs_[n] = ~regs_[m];
    } else if ((op & 0xF00Fu) == 0x6008u) {      // SWAP.B Rm,Rn
        const uint32_t value = regs_[m];
        regs_[n] = (value & 0xFFFF0000u) |
                   ((value & 0x000000FFu) << 8) |
                   ((value & 0x0000FF00u) >> 8);
    } else if ((op & 0xF00Fu) == 0x6009u) {      // SWAP.W Rm,Rn
        const uint32_t value = regs_[m];
        regs_[n] = (value << 16) | (value >> 16);
    } else if ((op & 0xF00Fu) == 0x600Bu) {      // NEG Rm,Rn
        regs_[n] = 0u - regs_[m];
    } else if ((op & 0xF00Fu) == 0x600Cu) {      // EXTU.B Rm,Rn
        regs_[n] = regs_[m] & 0xFFu;
    } else if ((op & 0xF00Fu) == 0x600Du) {      // EXTU.W Rm,Rn
        regs_[n] = regs_[m] & 0xFFFFu;
    } else if ((op & 0xF00Fu) == 0x600Eu) {      // EXTS.B Rm,Rn
        regs_[n] = static_cast<uint32_t>(static_cast<int32_t>(
            static_cast<int8_t>(regs_[m] & 0xFFu)));
    } else if ((op & 0xF00Fu) == 0x600Fu) {      // EXTS.W Rm,Rn
        regs_[n] = static_cast<uint32_t>(static_cast<int32_t>(
            static_cast<int16_t>(regs_[m] & 0xFFFFu)));
    } else if ((op & 0xF00Fu) == 0x3008u) {      // SUB Rm,Rn
        regs_[n] -= regs_[m];
    } else if ((op & 0xF00Fu) == 0x300Cu) {      // ADD Rm,Rn
        regs_[n] += regs_[m];
    } else if ((op & 0xF00Fu) == 0x300Eu) {      // ADDC Rm,Rn
        const uint64_t sum = static_cast<uint64_t>(regs_[n]) + regs_[m] +
                             (t_bit() ? 1u : 0u);
        regs_[n] = static_cast<uint32_t>(sum);
        if ((sum >> 32) != 0) sr_ |= 1u; else sr_ &= ~1u;
    } else if ((op & 0xF00Fu) == 0x300Fu) {      // ADDV Rm,Rn
        const uint32_t lhs = regs_[n];
        const uint32_t rhs = regs_[m];
        const uint32_t result = lhs + rhs;
        regs_[n] = result;
        if (((lhs ^ result) & (rhs ^ result) & 0x80000000u) != 0)
            sr_ |= 1u;
        else
            sr_ &= ~1u;
    } else if ((op & 0xF00Fu) == 0x300Au) {      // SUBC Rm,Rn
        const uint32_t lhs = regs_[n];
        const uint32_t rhs = regs_[m];
        const uint32_t borrow_in = t_bit() ? 1u : 0u;
        const uint64_t subtrahend = static_cast<uint64_t>(rhs) + borrow_in;
        regs_[n] = lhs - rhs - borrow_in;
        if (static_cast<uint64_t>(lhs) < subtrahend) sr_ |= 1u;
        else sr_ &= ~1u;
    } else if ((op & 0xF00Fu) == 0x300Bu) {      // SUBV Rm,Rn
        const uint32_t lhs = regs_[n];
        const uint32_t rhs = regs_[m];
        const uint32_t result = lhs - rhs;
        regs_[n] = result;
        if (((lhs ^ rhs) & (lhs ^ result) & 0x80000000u) != 0)
            sr_ |= 1u;
        else
            sr_ &= ~1u;
    } else if ((op & 0xF00Fu) == 0x200Cu) {      // CMP/STR Rm,Rn
        const uint32_t difference = regs_[n] ^ regs_[m];
        if ((difference & 0x000000FFu) == 0 ||
            (difference & 0x0000FF00u) == 0 ||
            (difference & 0x00FF0000u) == 0 ||
            (difference & 0xFF000000u) == 0)
            sr_ |= 1u;
        else
            sr_ &= ~1u;
    } else if ((op & 0xF00Fu) == 0x200Du) {      // XTRCT Rm,Rn
        regs_[n] = (regs_[n] >> 16) | (regs_[m] << 16);
    } else if ((op & 0xF00Fu) == 0x3000u) {      // CMP/EQ Rm,Rn
        if (regs_[n] == regs_[m]) sr_ |= 1u;
        else sr_ &= ~1u;
    } else if ((op & 0xF00Fu) == 0x3002u) {      // CMP/HS Rm,Rn (unsigned >=)
        if (regs_[n] >= regs_[m]) sr_ |= 1u;
        else sr_ &= ~1u;
    } else if ((op & 0xF00Fu) == 0x3003u) {      // CMP/GE Rm,Rn (signed >=)
        const uint32_t biased_n = regs_[n] ^ 0x80000000u;
        const uint32_t biased_m = regs_[m] ^ 0x80000000u;
        if (biased_n >= biased_m) sr_ |= 1u;
        else sr_ &= ~1u;
    } else if ((op & 0xF00Fu) == 0x3006u) {      // CMP/HI Rm,Rn (unsigned >)
        if (regs_[n] > regs_[m]) sr_ |= 1u;
        else sr_ &= ~1u;
    } else if ((op & 0xF00Fu) == 0x3007u) {      // CMP/GT Rm,Rn (signed >)
        const uint32_t biased_n = regs_[n] ^ 0x80000000u;
        const uint32_t biased_m = regs_[m] ^ 0x80000000u;
        if (biased_n > biased_m) sr_ |= 1u;
        else sr_ &= ~1u;
    } else if ((op & 0xF0FFu) == 0x4011u) {      // CMP/PZ Rn (signed >= 0)
        if ((regs_[n] & 0x80000000u) == 0) sr_ |= 1u;
        else sr_ &= ~1u;
    } else if ((op & 0xF0FFu) == 0x4015u) {      // CMP/PL Rn (signed > 0)
        if (regs_[n] != 0 && (regs_[n] & 0x80000000u) == 0) sr_ |= 1u;
        else sr_ &= ~1u;
    } else if ((op & 0xF0FFu) == 0x401Bu) {      // TAS.B @Rn
        const uint8_t value = bus_.read8(regs_[n]);
        if (value == 0) sr_ |= 1u;
        else sr_ &= ~1u;
        bus_.write8(regs_[n], static_cast<uint8_t>(value | 0x80u));
    } else if ((op & 0xFF00u) == 0x8800u) {      // CMP/EQ #imm8,R0
        const uint32_t immediate = static_cast<uint32_t>(sign_extend8(op));
        if (regs_[0] == immediate) sr_ |= 1u;
        else sr_ &= ~1u;
    } else if ((op & 0xF0FFu) == 0x4010u) {      // DT Rn
        --regs_[n];
        if (regs_[n] == 0) sr_ |= 1u;
        else sr_ &= ~1u;
    } else if ((op & 0xF0FFu) == 0x400Bu) {      // JSR @Rn (delayed)
        pr_ = pc_ + 2;
        schedule_branch(regs_[n]);
    } else if ((op & 0xF0FFu) == 0x402Bu) {      // JMP @Rn (delayed)
        schedule_branch(regs_[n]);
    } else if (op == 0x000Bu) {                  // RTS (delayed)
        schedule_branch(pr_);
    } else if ((op & 0xF000u) == 0xA000u) {      // BRA disp12 (delayed)
        const int32_t displacement = sign_extend12(op);
        schedule_branch(static_cast<uint32_t>(static_cast<int64_t>(pc_) + 2 +
                                               static_cast<int64_t>(displacement) * 2));
    } else if ((op & 0xF000u) == 0xB000u) {      // BSR disp12 (delayed)
        const int32_t displacement = sign_extend12(op);
        pr_ = pc_ + 2;
        schedule_branch(static_cast<uint32_t>(static_cast<int64_t>(pc_) + 2 +
                                               static_cast<int64_t>(displacement) * 2));
    } else if ((op & 0xFF00u) == 0x8900u) {      // BT disp8 (no delay slot)
        if (t_bit()) pc_ = static_cast<uint32_t>(static_cast<int64_t>(pc_) + 2 +
                                                static_cast<int64_t>(sign_extend8(op)) * 2);
    } else if ((op & 0xFF00u) == 0x8B00u) {      // BF disp8 (no delay slot)
        if (!t_bit()) pc_ = static_cast<uint32_t>(static_cast<int64_t>(pc_) + 2 +
                                                 static_cast<int64_t>(sign_extend8(op)) * 2);
    } else {
        ++unsupported_opcodes_;
    }

    // Branches in a delay slot are architecturally restricted; this minimal
    // core records the delay-slot instruction, then commits the older branch.
    if (apply_delayed_branch) {
        pc_ = delayed_target;
        branch_pending_ = false;
    }
    ++cycles_;
}
}
