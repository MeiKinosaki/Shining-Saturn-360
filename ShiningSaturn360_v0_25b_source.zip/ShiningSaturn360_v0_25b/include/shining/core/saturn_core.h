#pragma once
#include <stdint.h>
#include "shining/memory/memory_bus.h"
#include "shining/cpu/sh2.h"
#include "shining/scheduler/scheduler.h"

namespace shining {
class SaturnCore {
public:
    SaturnCore();
    bool initialize();
    void reset();
    void run_frame();
    void shutdown();
    bool initialized() const { return initialized_; }
    uint64_t frame_count() const { return frame_count_; }
    uint64_t scheduler_cycles() const { return scheduler_.cycles(); }
private:
    MemoryBus memory_;
    SH2 master_;
    SH2 slave_;
    Scheduler scheduler_;
    bool initialized_;
    uint64_t frame_count_;
};
}
