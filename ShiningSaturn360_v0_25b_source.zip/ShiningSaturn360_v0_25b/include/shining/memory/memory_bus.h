#pragma once
#include <stdint.h>
#include <stddef.h>
#include <vector>

namespace shining {
class MemoryBus {
public:
    explicit MemoryBus(size_t size = 2 * 1024 * 1024);
    void reset();
    uint8_t read8(uint32_t address) const;
    uint16_t read16(uint32_t address) const;
    uint32_t read32(uint32_t address) const;
    void write8(uint32_t address, uint8_t value);
    void write16(uint32_t address, uint16_t value);
    void write32(uint32_t address, uint32_t value);
    size_t size() const { return ram_.size(); }
private:
    std::vector<uint8_t> ram_;
};
}
