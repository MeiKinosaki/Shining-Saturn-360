#pragma once
extern "C" void xenon_entry();
