#pragma once
#include <stdint.h>
namespace shining {
class Scheduler {
public:
    Scheduler();
    void reset();
    void tick(uint32_t cycles);
    uint64_t cycles() const { return cycles_; }
private:
    uint64_t cycles_;
};
}
