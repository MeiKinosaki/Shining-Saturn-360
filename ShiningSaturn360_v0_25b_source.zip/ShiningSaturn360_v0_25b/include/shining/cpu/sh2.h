#pragma once
#include <stdint.h>

namespace shining {
class MemoryBus;

// Complete in-memory CPU checkpoint. This is a CPU context only; it does not
// serialize RAM or peripherals and is not yet a portable save-state format.
struct SH2State {
    uint32_t regs[16];
    uint32_t pc;
    uint32_t pr;
    uint32_t sr;
    uint32_t branch_target;
    bool branch_pending;
    uint16_t last_opcode;
    uint64_t cycles;
    uint64_t unsupported_opcodes;
};

class SH2 {
public:
    explicit SH2(MemoryBus& bus);
    void reset(uint32_t pc = 0);
    void step();
    uint32_t pc() const { return pc_; }
    uint32_t reg(unsigned index) const { return index < 16 ? regs_[index] : 0; }
    uint32_t pr() const { return pr_; }
    uint32_t sr() const { return sr_; }
    bool t_bit() const { return (sr_ & 1u) != 0; }
    uint16_t last_opcode() const { return last_opcode_; }
    uint64_t cycles() const { return cycles_; }
    uint64_t unsupported_opcodes() const { return unsupported_opcodes_; }
    SH2State save_state() const;
    void load_state(const SH2State& state);
private:
    void schedule_branch(uint32_t target);
    MemoryBus& bus_;
    uint32_t pc_;
    uint32_t regs_[16];
    uint32_t pr_;
    uint32_t sr_;
    uint32_t branch_target_;
    bool branch_pending_;
    uint16_t last_opcode_;
    uint64_t cycles_;
    uint64_t unsupported_opcodes_;
};
}
