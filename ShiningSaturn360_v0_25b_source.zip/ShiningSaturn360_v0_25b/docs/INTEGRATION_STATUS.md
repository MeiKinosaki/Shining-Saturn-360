# SaturnCore ↔ Xenon entry

## Integrado

- `main()` instancia `SaturnCore`.
- `SaturnCore::initialize()` é chamado antes do loop.
- `run_frame()` é chamado continuamente.
- O build Xenon inclui o objeto de `saturn_core.cpp`.

## Ainda não comprovado

Esta integração é um contrato mínimo de entrada. Ela não representa ainda
todos os subsistemas Saturn (SH-2, VDP1/VDP2, SCSP, CD Block, SMPC etc.)
conectados ao loop Xenon.

Também não há `xenon.elf` ou `default.xex` neste pacote porque o toolchain
Xenon real não está disponível neste ambiente.
