# Host tests — v0.13b

Run from the project root:

```sh
./scripts/run-host-tests.sh
```

The smoke suite covers MemoryBus big-endian reads/writes and bounds, SH-2 basic arithmetic/moves, SR.T flag operations, compare and decrement instructions, conditional and delayed branches, byte/word/longword memory transfers, sign extension, pre-decrement stores, post-increment loads, scheduler counters, and SaturnCore lifecycle. Passing host tests does not prove libXenon build success or correctness on Xbox 360 hardware.
