# C++ compatibility review (package v5)

The Makefile now requests `-std=gnu++98` instead of C++17. This is a conservative compatibility choice for older Xenon GCC toolchains. Fixed-width integer types use `<stdint.h>`, and members that had in-class initializers are initialized in constructors.

A host build with `g++ -std=gnu++98 -Wall -Wextra` succeeded for the five current translation units. This is only a source-compatibility check; it does not establish that `xenon-g++` is installed, that the target link succeeds, or that the result boots on Xbox 360.
