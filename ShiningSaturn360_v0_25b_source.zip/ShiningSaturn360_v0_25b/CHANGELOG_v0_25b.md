# Shining Saturn 360 v0.25b

## CPU SH-2
- Implemented the `SUB Rm,Rn` register subtraction instruction (`0x3nm8`).
- Added regression coverage for signed-boundary wraparound, unsigned wraparound, equal operands, and preservation of the `T` flag.
- Kept the release sequence consecutive after v0.24b.

## Validation scope
Host tests validate the current interpreter implementation only. This release does not claim a successful libXenon build, a generated `Xenon.elf32`/`default.xex`, or execution on Xbox 360 hardware.
